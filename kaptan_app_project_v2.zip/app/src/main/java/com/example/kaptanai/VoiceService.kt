package com.example.kaptanai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.util.Locale
import kotlin.concurrent.thread
import android.content.SharedPreferences
import android.preference.PreferenceManager
import android.util.Log
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

data class ChatMessage(val role: String, val content: String)
data class OpenAIRequest(val model: String = "gpt-4o-mini", val messages: List<ChatMessage>)
data class Choice(val index: Int, val message: ChatMessage)
data class OpenAIResponse(val id: String?, val choices: List<Choice>?)

interface OpenAIService {
    @POST("v1/chat/completions")
    suspend fun chat(@Header("Authorization") auth: String, @Body body: OpenAIRequest): OpenAIResponse
}

class VoiceService : Service() {
    private lateinit var tts: TextToSpeech
    private var running = false
    private var job: Job? = null
    private var wakeWord: String = "Kaptan"
    private var ignoreListening = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, buildNotification())

        val prefs = getSharedPreferences("kaptan_prefs", MODE_PRIVATE)
        wakeWord = prefs.getString("wake_word", "Kaptan") ?: "Kaptan"

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
            }
        }

        // Start a simple audio capture loop in background thread.
        running = true
        job = CoroutineScope(Dispatchers.Default).launch {
            startListeningLoop()
        }
    }

    private suspend fun startListeningLoop() {
        // Placeholder: using AudioRecord and naive keyword matching on hypothetical ASR output.
        // For production, integrate Vosk or Picovoice for real wake-word and ASR.
        val sampleRate = 16000
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT)

        val recorder = AudioRecord(MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize)

        recorder.startRecording()
        val buffer = ShortArray(bufferSize)
        while (running) {
            val read = recorder.read(buffer, 0, buffer.size)
            if (read > 0) {
                // TODO: pipe to ASR; here we simulate partial recognition by checking for presence of wakeWord in a placeholder method.
                val simulatedText = simulateRecognitionFromBuffer(buffer, read)
                if (!ignoreListening && simulatedText.contains(wakeWord, ignoreCase = true)) {
                    // Detected wake word -> listen for user's following question (simplified)
                    val userQuestion = "Bu bir örnek soru (gerçek uygulamada gerçek ASR gerekir)."
                    handleUserQuestion(userQuestion)
                }
                // If the user says "Kaptan dur" anywhere, stop listening until restarted.
                if (simulatedText.contains("kaptan dur", ignoreCase = true) || simulatedText.contains("${wakeWord.toLowerCase()} dur", ignoreCase = true)) {
                    ignoreListening = true
                    tts.speak("Tamam kaptan, dinlemeyi durduruyorum.", TextToSpeech.QUEUE_FLUSH, null, "STOP_UTT")
                }
            }
            delay(200)
        }
        recorder.stop()
        recorder.release()
    }

    private fun simulateRecognitionFromBuffer(buffer: ShortArray, read: Int): String {
        // This is a stub used only for the prototype. Replace with real ASR.
        // For easier testing, developers can send intents or call handleUserQuestion directly.
        return ""
    }

    private fun handleUserQuestion(userText: String) {
        // Make OpenAI call (in coroutine) and then TTS the result with natural/samimi prefix
        CoroutineScope(Dispatchers.IO).launch {
            val reply = askOpenAI(userText)
            val natural = "Tamam kaptan — şöyle: " + reply
            tts.speak(natural, TextToSpeech.QUEUE_FLUSH, null, "RESP_UTT")
        }
    }

    private suspend fun askOpenAI(prompt: String): String {
        try {
            // If BuildConfig.OPENAI_API_KEY is empty, app will try backend at http://10.0.2.2:3000/chat or configured base.
            val key = BuildConfig.OPENAI_API_KEY
            if (key != null && key.isNotBlank()) {
                val retrofit = Retrofit.Builder()
                    .baseUrl("https://api.openai.com/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                val service = retrofit.create(OpenAIService::class.java)
                val messages = listOf(ChatMessage("user", prompt))
                val resp = service.chat("Bearer $key", OpenAIRequest(messages = messages))
                val txt = resp.choices?.firstOrNull()?.message?.content ?: "Üzgünüm, cevap alınamadı."
                return txt
            } else {
                // Try backend proxy
                val retrofit = Retrofit.Builder()
                    .baseUrl("http://10.0.2.2:3000/") // emulator local, or change to backend IP
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                val proxy = retrofit.create(BackendService::class.java)
                val resp = proxy.chat(mapOf("prompt" to prompt))
                val choices = resp["choices"] as? List<Map<String,Any>>
                val message = choices?.get(0)?.get("message") as? Map<String, Any>
                val content = message?.get("content") as? String
                return content ?: "Üzgünüm, proxy üzerinden cevap alınamadı."
            }
        } catch (e: Exception) {
            Log.e("VoiceService", "OpenAI error", e)
            return "Bir hata oluştu: ${e.message}"
        }
    }

    interface BackendService {
        @POST("/chat")
        suspend fun chat(@Body body: Map<String, String>): Map<String, Any>
    }

    override fun onDestroy() {
        running = false
        job?.cancel()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
